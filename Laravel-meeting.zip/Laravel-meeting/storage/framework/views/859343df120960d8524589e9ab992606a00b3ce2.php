<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Edit Permission
    </div>

    <div class="card-body">
        <form id="permission_form" name="permission_form" action="<?php echo e(route("admin.permissions.update", [$permission->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="title">title*</label>
                <input type="text" id="title" name="title" class="form-control" value="<?php echo e(old('title', isset($permission) ? $permission->title : '')); ?>" required>
                
                
            </div>
            <div>
                <input type="submit" name="save" value="Save" class="btn btn-primary">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Laravel-meeting/resources/views/admin/permissions/edit.blade.php ENDPATH**/ ?>