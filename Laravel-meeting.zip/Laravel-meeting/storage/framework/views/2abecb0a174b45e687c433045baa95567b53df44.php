<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service_create')): ?>
<div style="margin-bottom: 10px;" class="row">
    <div class="form-group srh_w_d">
        <a href="javascript:void(0)" data-url="services/addService" id="add_service" class="btn btn-primary">Add Meeting</a>
    </div>
</div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        Meetings Name List
    </div>

    <div class="card-body">
        <table id="service-datatable" class=" table table-bordered table-striped table-hover ajaxTable datatable">
            <thead>
                <tr>
                   
                    <th>
                        Id
                    </th>
                    <th>
                        Name
                    </th>
                    <th>
                       Actions
                    </th>
                </tr>
            </thead>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<!-- Add Service Meeting Modal -->
<div class="modal fade" id="ServiceModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" id="service_modal_content">
        </div>
    </div>
</div>
<!-- End Service Meeting  Modal -->

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/additional-methods.js')); ?>"></script>
<script src="<?php echo e(asset('js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-multiselect.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/service_list.js')); ?>"></script>
<script src="<?php echo e(asset('js/common.js')); ?>"></script>
<script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Laravel-meeting/resources/views/admin/services/index.blade.php ENDPATH**/ ?>