<?php $__env->startSection('content'); ?>

<div style="margin-bottom: 10px;" class="row">
<div class="col-lg-12">
        <a href="javascript:void(0)" data-url="appointments/addAppointment" id="add_appointment" class="btn btn-primary">Add Appointment</a>
    </div>
</div>

<div class="card">
    <div class="card-header">
        Meeting list
    </div>

    <div class="card-body">
        <table class=" table table-bordered table-striped table-hover ajaxTable datatable datatable-Appointment">
            <thead>
                <tr>
                    <th width="10">

                    </th>
                    <th>
                        Id
                    </th>
                    <th>
                        Client Name
                    </th>
                    <th>
                        Start Time
                    </th>
                    <th>
                        Finish Time
                    </th>
                    <th>
                        Meeting Name
                    </th>
                    <th>
                        &nbsp;
                    </th>
                </tr>
            </thead>
        </table>


    </div>
</div>
<?php $__env->stopSection(); ?>

<!-- Add Appointment Modal -->
<div class="modal fade" id="AppointmentModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" id="appointment_modal_content">
        </div>
    </div>
</div>
<!-- End Appointment Modal -->

<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
$(function() {
    var dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('appointment_delete')): ?>
    var deleteButtonTrans = 'Delete';
    var deleteButton = {
        text: deleteButtonTrans,
        url: "<?php echo e(route('admin.appointments.massDestroy')); ?>",
        method:"POST",
        className: 'btn-danger',
        action: function(e, dt, node, config) {
            var ids = $.map(dt.rows({
                selected: true
            }).data(), function(entry) {
                return entry.id
            });

            if (ids.length === 0) {
                alert('<?php echo e(trans('global.datatables.zero_selected ')); ?>')

                return
            }

            if (confirm('<?php echo e(trans('global.areYouSure ')); ?>')) {
                $.ajax({
                        headers: {
                            'x-csrf-token': _token
                        },
                        method: 'POST',
                        url: config.url,
                        data: {
                            ids: ids,
                            _method: 'DELETE'
                        }
                    })
                    .done(function() {
                        location.reload()
                    })
            }
        }
    }
    dtButtons.push(deleteButton)
    <?php endif; ?>

    var appointments = {
        buttons: dtButtons,
        processing: true,
        serverSide: true,
        retrieve: true,
        aaSorting: [],
        ajax: "<?php echo e(route('admin.appointments.index')); ?>",
        
        columns: [{
                data: 'placeholder',
                name: 'placeholder'
            },
            {
                data: 'id',
                name: 'id'
            },
            {
                data: 'client_name',
                name: 'client.name'
            },
            {
                data: 'start_time',
                name: 'start_time'
            },
            {
                data: 'finish_time',
                name: 'finish_time'
            },
            {
                data: 'services',
                name: 'services.name'
            },
            {
                data: 'actions',
                name: '<?php echo e(trans('global.actions ')); ?>'
            }
        ],
        order: [
            [1, 'desc']
        ],
        pageLength: 100,
    };
    $('.datatable-Appointment').DataTable(appointments);
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });

});
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/additional-methods.js')); ?>"></script>
<script src="<?php echo e(asset('js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-multiselect.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/appointment.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Laravel-meeting/resources/views/admin/appointments/index.blade.php ENDPATH**/ ?>