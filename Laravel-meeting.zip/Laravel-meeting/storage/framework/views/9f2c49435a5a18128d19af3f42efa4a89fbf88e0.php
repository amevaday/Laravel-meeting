<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
       Add Permission
    </div>

    <div class="card-body">
        <form id="permission_form" name="permission_form" action="<?php echo e(route("admin.permissions.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="title">Title*</label>
                <input type="text" id="title" name="title" class="form-control" value="<?php echo e(old('title', isset($permission) ? $permission->title : '')); ?>" required>
               
               
            </div>
            <div>
                <input type="submit" name="save" value="Save" class="btn btn-primary">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/permission_create.js')); ?>"></script>
<script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Laravel-meeting/resources/views/admin/permissions/create.blade.php ENDPATH**/ ?>