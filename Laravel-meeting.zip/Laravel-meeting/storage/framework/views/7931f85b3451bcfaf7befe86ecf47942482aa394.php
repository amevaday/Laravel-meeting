<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
       Edit Meeting
    </div>

    <div class="card-body">
        <form id="services_form" name="services_form" action="<?php echo e(route("admin.services.update", [$service->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="name">Name*</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', isset($service) ? $service->name : '')); ?>" >
               
            </div>
            
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Laravel-meeting/resources/views/admin/services/edit.blade.php ENDPATH**/ ?>