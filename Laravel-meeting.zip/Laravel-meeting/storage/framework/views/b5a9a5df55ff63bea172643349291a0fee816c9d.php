<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Edit Client List
    </div>

    <div class="card-body">
        <form id="create-client-form" name="create-client-form" action="<?php echo e(route("admin.clients.update", [$client->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', isset($client) ? $client->name : '')); ?>">
                
            </div>
            <div class="form-group ">
                <label for="phone">Phone</label>
                <input type="text" id="phone" name="phone" class="form-control" value="<?php echo e(old('phone', isset($client) ? $client->phone : '')); ?>">
               
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo e(old('email', isset($client) ? $client->email : '')); ?>">
                
            </div>
            <div>
                <input type="submit" name="save" value="Save" class="btn btn-primary">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Laravel-meeting/resources/views/admin/clients/edit.blade.php ENDPATH**/ ?>