<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
       Edit Appointment
    </div>

    <div class="card-body">
        <form id="appointment-user-form" name="appointment-user-form" action="<?php echo e(route("admin.appointments.update", [$appointment->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="client">Client*</label>
                <select name="client_id" id="client" class="form-control select2">
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((isset($appointment) && $appointment->client ? $appointment->client->id : old('client_id')) == $id ? 'selected' : ''); ?>><?php echo e($client); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
               
            </div>
     
            <div class="form-group">
                <label for="start_time">Start Time*</label>
                <input type="text" id="start_time" name="start_time" class="form-control datetime" value="<?php echo e(old('start_time', isset($appointment) ? $appointment->start_time : '')); ?>">
               
               
            </div>
            <div class="form-group ">
                <label for="finish_time">Finish Time*</label>
                <input type="text" id="finish_time" name="finish_time" class="form-control datetime" value="<?php echo e(old('finish_time', isset($appointment) ? $appointment->finish_time : '')); ?>">
               
                
            </div>
            
            <div class="form-group">
                <label for="services">Meeting Title 
                    <span class="btn btn-info btn-xs select-all"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all"><?php echo e(trans('global.deselect_all')); ?></span></label>
                <select name="services[]" id="services" class="form-control select2" multiple="multiple">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('services', [])) || isset($appointment) && $appointment->services->contains($id)) ? 'selected' : ''); ?>><?php echo e($services); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
               
            </div>
            <div>
                <input type="submit" name="save" value="Save" class="btn btn-primary">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Laravel-meeting/resources/views/admin/appointments/edit.blade.php ENDPATH**/ ?>